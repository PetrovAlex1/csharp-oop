﻿namespace Telephony
{
	public interface IBrowsable
	{
		string URL { get; }
	}
}
