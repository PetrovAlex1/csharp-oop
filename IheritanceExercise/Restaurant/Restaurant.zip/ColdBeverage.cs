﻿namespace Restaurant
{
	class ColdBeverage : Beverages
	{
		public ColdBeverage(string name, decimal price, double milliliters)
			: base(name, price, milliliters)
		{

		}
	}
}
